const express = require('express');
const controller = require('../controllers/connectionController');

const router = express.Router();

//GET /connections: send all connections to the user
router.get('/', controller.index);

//GET /connections/new: send html form for creating a new connection
router.get('/new', controller.new);

//POST /connection: create a new story
router.post('/', controller.create);

//GET /connection/:id: send details of story identified by id
router.get('/:id', controller.show);

//GET /connection/:id: send html form for editiing an existing story
router.get('/:id/edit', controller.edit);

//PUT /connection/:id: update the story by identified id
router.put('/:id', controller.update);

//DELETE /connection/:id: delete the story identified by id
router.delete('/:id', controller.delete);

module.exports = router;