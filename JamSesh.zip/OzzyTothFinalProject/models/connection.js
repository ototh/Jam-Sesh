const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const connectionSchema = new Schema({
    title: {type: String, required: [true, 'title is required']},
    category: {type: String, required: [true, 'category is required']},
    details: {type: String, required: [true, 'details are required'],
        minlength: [10, 'details should have at least 10 characters']},
    date: {type: String, required: [true, 'date is required']},
    startTime: {type: String, required: [true, 'start time is required']},
    endTime: {type: String, required: [true, 'end time is required']},
    location: {type: String, required: [true, 'location is required']},
    host: {type: String, required: [true, 'location is required']},
    image: {type: String, required: [true, 'image is required']},
}
);

//collection name is connections in database
module.exports = mongoose.model('Connection', connectionSchema);
